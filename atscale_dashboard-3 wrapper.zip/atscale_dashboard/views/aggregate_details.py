import os

import streamlit as st

from utils.ui import inject_global_css, render_sidebar
from utils.atscale_wrapper import (
    ENV_CONFIG,
    login,
    run_list_aggregates,
    run_export_csv,
    run_statistics,
    run_health_check,
    get_aggregates_dataframe,
)

inject_global_css()
render_sidebar()

st.title("📊 Aggregate Details")
st.caption(
    "Wraps the real, unmodified atscale-aggregate-util code "
    "(vendor/atscale_util/) — auth, API calls, and report/stats/health "
    "logic are exactly as authored upstream."
)

ss = st.session_state
ss.setdefault("as_env", None)
ss.setdefault("as_authenticated", False)
ss.setdefault("as_client", None)
ss.setdefault("as_projects", None)
ss.setdefault("as_username", None)

WORK_DIR = os.path.join("/home/claude", "atscale_csv_exports")

# ---------------------------------------------------------------------------
# STEP 1 — Environment picker
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">1. Select Environment</div>', unsafe_allow_html=True)

env_choice = st.selectbox(
    "Environment",
    options=list(ENV_CONFIG.keys()),
    index=None,
    placeholder="Choose Dev / Uat / Prod...",
    key="env_selectbox",
)

if env_choice and env_choice != ss.as_env:
    ss.as_env = env_choice
    ss.as_authenticated = False
    ss.as_client = None
    ss.as_projects = None

if env_choice:
    cfg = ENV_CONFIG[env_choice]
    st.caption(f"Host: `{cfg['host']}` · Organization: `{cfg['organization']}` · Instance type: `installer`")

# ---------------------------------------------------------------------------
# STEP 2 — Login (hidden after success)
# ---------------------------------------------------------------------------
if env_choice and not ss.as_authenticated:
    st.markdown('<div class="section-header">2. Login</div>', unsafe_allow_html=True)
    with st.form("atscale_login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("🔐 Login", type="primary")

    if submitted:
        with st.spinner(f"Authenticating against {ENV_CONFIG[env_choice]['host']}..."):
            try:
                client, projects = login(env_choice, username, password)
            except Exception as exc:  # noqa: BLE001 - surface the real underlying error
                st.error(f"Login failed: {exc}")
            else:
                ss.as_authenticated = True
                ss.as_client = client
                ss.as_projects = projects
                ss.as_username = username
                st.rerun()

# ---------------------------------------------------------------------------
# Authenticated area
# ---------------------------------------------------------------------------
if ss.as_authenticated and ss.as_client:
    c1, c2 = st.columns([5, 1])
    with c1:
        st.success(f"Logged in as **{ss.as_username}** to **{env_choice}** ({ENV_CONFIG[env_choice]['host']})")
    with c2:
        if st.button("Logout", use_container_width=True):
            for key in ("as_authenticated", "as_client", "as_projects", "as_username"):
                ss[key] = None if key != "as_authenticated" else False
            st.rerun()

    # -- STEP 3: Cube picker (All Cubes option) -----------------------------
    st.markdown('<div class="section-header">3. Select Cube</div>', unsafe_allow_html=True)

    projects = ss.as_projects or []
    catalog_options = {p.get("name", p.get("id", "Unknown")): p for p in projects}
    catalog_name = st.selectbox("Project / Catalog", options=list(catalog_options.keys()) or ["(none published)"])

    catalog = catalog_options.get(catalog_name)
    cubes = catalog.get("cubes", []) if catalog else []
    cube_names = ["All Cubes"] + [c.get("name", c.get("id", "Unknown")) for c in cubes]
    cube_choice = st.selectbox("Cube", options=cube_names)

    fetch = st.button("📥 Load Aggregate Data", type="primary", disabled=catalog is None)

    def _cube_data(catalog_obj, cube_obj) -> dict:
        return {
            "project_id": catalog_obj["id"],
            "cube_id": cube_obj["id"],
            "display": f"{catalog_obj.get('name', catalog_obj['id'])} / {cube_obj.get('name', cube_obj['id'])}",
        }

    if fetch and catalog:
        if cube_choice == "All Cubes":
            selected_cubes = [_cube_data(catalog, c) for c in cubes]
        else:
            cube_obj = next(c for c in cubes if c.get("name", c.get("id")) == cube_choice)
            selected_cubes = [_cube_data(catalog, cube_obj)]
        ss.as_selected_cubes = selected_cubes

    # -- STEP 4: Aggregate Report (vendored output + interactive view + CSV) --
    if ss.get("as_selected_cubes"):
        st.markdown('<div class="section-header">Aggregate Report</div>', unsafe_allow_html=True)

        report_texts = []
        dataframes = []
        csv_paths = []

        with st.spinner("Running vendored report / stats / health checks..."):
            for cd in ss.as_selected_cubes:
                try:
                    report_texts.append(f"=== {cd['display']} ===\n" + run_list_aggregates(ss.as_client, cd))
                    dataframes.append(get_aggregates_dataframe(ss.as_client, cd))
                    csv_path = run_export_csv(ss.as_client, cd, WORK_DIR)
                    if csv_path:
                        csv_paths.append(csv_path)
                except Exception as exc:  # noqa: BLE001
                    report_texts.append(f"=== {cd['display']} ===\nError: {exc}")

        st.markdown("**Original CLI output (unmodified `CubeAggregateReporter`)**")
        st.text_area("report_output", value="\n\n".join(report_texts), height=350, disabled=True, label_visibility="collapsed")

        if csv_paths:
            if len(csv_paths) == 1:
                with open(csv_paths[0], "rb") as f:
                    st.download_button(
                        "⬇️ Export Aggregates to CSV (real file, real fieldnames)",
                        data=f.read(),
                        file_name=os.path.basename(csv_paths[0]),
                        mime="text/csv",
                        type="primary",
                    )
            else:
                import zipfile
                zip_path = os.path.join(WORK_DIR, "aggregates_all_cubes.zip")
                with zipfile.ZipFile(zip_path, "w") as zf:
                    for p in csv_paths:
                        zf.write(p, arcname=os.path.basename(p))
                with open(zip_path, "rb") as f:
                    st.download_button(
                        "⬇️ Export All Cubes to CSV (zip of real per-cube files)",
                        data=f.read(),
                        file_name="aggregates_all_cubes.zip",
                        mime="application/zip",
                        type="primary",
                    )

        if dataframes:
            import pandas as pd
            combined_df = pd.concat(dataframes, ignore_index=True)
            st.markdown("**Interactive view** *(wrapper-built from the same unmodified API response — sort by clicking a column header, filter below)*")

            f1, f2 = st.columns(2)
            with f1:
                status_filter = st.multiselect(
                    "Filter by status", sorted(combined_df["status"].dropna().unique()),
                    default=list(combined_df["status"].dropna().unique()), key="status_filter",
                )
            with f2:
                cube_filter = st.multiselect(
                    "Filter by cube", sorted(combined_df["cube"].dropna().unique()),
                    default=list(combined_df["cube"].dropna().unique()), key="cube_filter",
                )
            view = combined_df[combined_df["status"].isin(status_filter) & combined_df["cube"].isin(cube_filter)]
            st.dataframe(view, use_container_width=True, hide_index=True, height=min(450, 45 + 35 * len(view)))
            st.download_button(
                "⬇️ Export current interactive view to CSV",
                data=view.to_csv(index=False).encode("utf-8"),
                file_name="aggregates_interactive_view.csv",
                mime="text/csv",
            )

        # -- STEP 5: Aggregate Statistics (vendored output) --------------------
        st.markdown('<div class="section-header">Aggregate Statistics</div>', unsafe_allow_html=True)
        stats_texts = []
        for cd in ss.as_selected_cubes:
            try:
                stats_texts.append(f"=== {cd['display']} ===\n" + run_statistics(ss.as_client, cd))
            except Exception as exc:  # noqa: BLE001
                stats_texts.append(f"=== {cd['display']} ===\nError: {exc}")
        st.text_area("stats_output", value="\n\n".join(stats_texts), height=400, disabled=True, label_visibility="collapsed")

        # -- STEP 6: Aggregate Health Check (vendored output) -------------------
        st.markdown('<div class="section-header">Aggregate Health Check</div>', unsafe_allow_html=True)
        health_texts = []
        for cd in ss.as_selected_cubes:
            try:
                health_texts.append(f"=== {cd['display']} ===\n" + run_health_check(ss.as_client, cd))
            except Exception as exc:  # noqa: BLE001
                health_texts.append(f"=== {cd['display']} ===\nError: {exc}")
        st.text_area("health_output", value="\n\n".join(health_texts), height=400, disabled=True, label_visibility="collapsed")

elif not env_choice:
    st.info("Pick an environment above to begin.")
