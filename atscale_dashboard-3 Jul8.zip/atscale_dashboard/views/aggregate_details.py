import os
import zipfile

import pandas as pd
import streamlit as st

from utils.ui import inject_global_css, render_sidebar
from utils.atscale_wrapper import (
    ENV_CONFIG,
    login,
    run_list_aggregates,
    run_export_csv,
    run_statistics,
    run_health_check,
    get_aggregates_dataframe,
)

inject_global_css()
render_sidebar()

st.title("📊 Aggregate Details")
st.caption(
    "Wraps the real, unmodified atscale-aggregate-util code "
    "(vendor/atscale_util/) — auth, API calls, and report/stats/health "
    "logic are exactly as authored upstream."
)

ss = st.session_state
ss.setdefault("as_env", None)
ss.setdefault("as_authenticated", False)
ss.setdefault("as_client", None)
ss.setdefault("as_projects", None)
ss.setdefault("as_username", None)

WORK_DIR = os.path.join("/home/claude", "atscale_csv_exports")


def _cube_data(catalog_obj, cube_obj) -> dict:
    return {
        "project_id": catalog_obj["id"],
        "cube_id": cube_obj["id"],
        "display": f"{catalog_obj.get('name', catalog_obj['id'])} / {cube_obj.get('name', cube_obj['id'])}",
    }


def _show_console_block(text: str, height: int = 350) -> None:
    """Non-wrapping, monospace, scrollable block for vendored CLI output
    (st.code doesn't wrap long lines - it scrolls horizontally instead,
    which keeps the original tool's column alignment intact)."""
    with st.container(height=height, border=True):
        st.code(text or "(no output)", language=None)


# ---------------------------------------------------------------------------
# STEP 1 — Environment picker
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">1. Select Environment</div>', unsafe_allow_html=True)

env_choice = st.selectbox(
    "Environment",
    options=list(ENV_CONFIG.keys()),
    index=None,
    placeholder="Choose Dev / Uat / Prod...",
    key="env_selectbox",
)

if env_choice and env_choice != ss.as_env:
    ss.as_env = env_choice
    ss.as_authenticated = False
    ss.as_client = None
    ss.as_projects = None

if env_choice:
    cfg = ENV_CONFIG[env_choice]
    st.caption(f"Host: `{cfg['host']}` · Organization: `{cfg['organization']}` · Instance type: `installer`")

# ---------------------------------------------------------------------------
# STEP 2 — Login (hidden after success)
# ---------------------------------------------------------------------------
if env_choice and not ss.as_authenticated:
    st.markdown('<div class="section-header">2. Login</div>', unsafe_allow_html=True)
    with st.form("atscale_login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("🔐 Login", type="primary")

    if submitted:
        with st.spinner(f"Authenticating against {ENV_CONFIG[env_choice]['host']}..."):
            try:
                client, projects = login(env_choice, username, password)
            except Exception as exc:  # noqa: BLE001 - surface the real underlying error
                st.error(f"Login failed: {exc}")
            else:
                ss.as_authenticated = True
                ss.as_client = client
                ss.as_projects = projects
                ss.as_username = username
                st.rerun()

# ---------------------------------------------------------------------------
# Authenticated area
# ---------------------------------------------------------------------------
if ss.as_authenticated and ss.as_client:
    c1, c2 = st.columns([5, 1])
    with c1:
        st.success(f"Logged in as **{ss.as_username}** to **{env_choice}** ({ENV_CONFIG[env_choice]['host']})")
    with c2:
        if st.button("Logout", use_container_width=True):
            for key in ("as_authenticated", "as_client", "as_projects", "as_username"):
                ss[key] = None if key != "as_authenticated" else False
            st.rerun()

    # -- STEP 3: Cube picker (single cube only - no "All Cubes" option) -----
    st.markdown('<div class="section-header">3. Select Cube</div>', unsafe_allow_html=True)

    projects = ss.as_projects or []
    catalog_options = {p.get("name", p.get("id", "Unknown")): p for p in projects}
    catalog_name = st.selectbox("Project / Catalog", options=list(catalog_options.keys()) or ["(none published)"])

    catalog = catalog_options.get(catalog_name)
    cubes = catalog.get("cubes", []) if catalog else []
    cube_names = [c.get("name", c.get("id", "Unknown")) for c in cubes]
    cube_choice = st.selectbox("Cube", options=cube_names or ["(no cubes published)"])

    b1, b2 = st.columns([1, 1.4])
    with b1:
        fetch = st.button("📥 Load Aggregate Data", type="primary", disabled=catalog is None)
    with b2:
        all_cubes_export = st.button(
            "📦 Download All-Cubes Aggregate Report (CSV)",
            disabled=catalog is None,
            use_container_width=True,
        )

    if fetch and catalog:
        cube_obj = next(c for c in cubes if c.get("name", c.get("id")) == cube_choice)
        ss.as_selected_cube = _cube_data(catalog, cube_obj)

    # -- Dedicated all-cubes CSV button: loops every cube in this catalog,
    #    calls the real unmodified export function per cube, then combines
    #    every real row into ONE CSV. -----------------------------------------
    if all_cubes_export and catalog:
        combined_rows = []
        with st.spinner(f"Looping through {len(cubes)} cube(s) and exporting each via the real export function..."):
            for cube_obj in cubes:
                cd = _cube_data(catalog, cube_obj)
                try:
                    csv_path = run_export_csv(ss.as_client, cd, WORK_DIR)
                    if csv_path:
                        df = pd.read_csv(csv_path)
                        df.insert(0, "cube", cd["display"])
                        combined_rows.append(df)
                except Exception as exc:  # noqa: BLE001
                    st.warning(f"Skipped {cd['display']}: {exc}")

        if combined_rows:
            combined = pd.concat(combined_rows, ignore_index=True)
            st.success(f"Combined {len(cubes)} cube(s) into one report ({len(combined)} aggregate rows).")
            st.download_button(
                "⬇️ Download Combined All-Cubes CSV",
                data=combined.to_csv(index=False).encode("utf-8"),
                file_name=f"aggregate_report_all_cubes_{env_choice}.csv",
                mime="text/csv",
                type="primary",
                key="all_cubes_csv_dl",
            )
        else:
            st.info("No aggregates found across any cube in this catalog.")

    # -- STEP 4: Aggregate Report (single selected cube) ---------------------
    if ss.get("as_selected_cube"):
        cd = ss.as_selected_cube
        st.markdown('<div class="section-header">Aggregate Report</div>', unsafe_allow_html=True)

        with st.spinner(f"Running vendored report for {cd['display']}..."):
            try:
                report_text = run_list_aggregates(ss.as_client, cd)
            except Exception as exc:  # noqa: BLE001
                report_text = f"Error: {exc}"
            try:
                df = get_aggregates_dataframe(ss.as_client, cd)
            except Exception:  # noqa: BLE001
                df = pd.DataFrame()
            try:
                csv_path = run_export_csv(ss.as_client, cd, WORK_DIR)
            except Exception:  # noqa: BLE001
                csv_path = None

        st.markdown("**Original CLI output (unmodified `CubeAggregateReporter`)**")
        _show_console_block(report_text, height=350)

        if csv_path:
            with open(csv_path, "rb") as f:
                st.download_button(
                    "⬇️ Export to CSV (this cube — real file, real fieldnames)",
                    data=f.read(),
                    file_name=os.path.basename(csv_path),
                    mime="text/csv",
                    type="primary",
                    key="report_csv_dl",
                )

        if not df.empty:
            st.markdown("**Interactive view** *(wrapper-built from the same unmodified API response — click a column header to sort)*")
            status_filter = st.multiselect(
                "Filter by status", sorted(df["status"].dropna().unique()),
                default=list(df["status"].dropna().unique()), key="status_filter",
            )
            view = df[df["status"].isin(status_filter)]
            st.dataframe(view, use_container_width=True, hide_index=True, height=min(450, 45 + 35 * len(view)))
            st.download_button(
                "⬇️ Export current interactive view to CSV",
                data=view.to_csv(index=False).encode("utf-8"),
                file_name=f"aggregates_interactive_{cd['display'].replace(' ', '_').replace('/', '-')}.csv",
                mime="text/csv",
                key="interactive_csv_dl",
            )

        # -- STEP 5: Aggregate Statistics ------------------------------------
        st.markdown('<div class="section-header">Aggregate Statistics</div>', unsafe_allow_html=True)
        try:
            stats_text = run_statistics(ss.as_client, cd)
        except Exception as exc:  # noqa: BLE001
            stats_text = f"Error: {exc}"
        _show_console_block(stats_text, height=420)
        st.download_button(
            "⬇️ Export Statistics (.txt — exact console output)",
            data=stats_text.encode("utf-8"),
            file_name=f"aggregate_statistics_{cd['display'].replace(' ', '_').replace('/', '-')}.txt",
            mime="text/plain",
            key="stats_txt_dl",
        )

        # -- STEP 6: Aggregate Health Check -----------------------------------
        st.markdown('<div class="section-header">Aggregate Health Check</div>', unsafe_allow_html=True)
        try:
            health_text = run_health_check(ss.as_client, cd)
        except Exception as exc:  # noqa: BLE001
            health_text = f"Error: {exc}"
        _show_console_block(health_text, height=420)
        st.download_button(
            "⬇️ Export Health Check (.txt — exact console output)",
            data=health_text.encode("utf-8"),
            file_name=f"aggregate_health_{cd['display'].replace(' ', '_').replace('/', '-')}.txt",
            mime="text/plain",
            key="health_txt_dl",
        )

elif not env_choice:
    st.info("Pick an environment above to begin.")
