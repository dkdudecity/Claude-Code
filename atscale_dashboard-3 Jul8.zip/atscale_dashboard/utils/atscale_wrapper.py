"""
Thin Streamlit-facing wrapper around the vendored, UNMODIFIED
atscale-aggregate-util code living in vendor/atscale_util/.

This module does NOT alter any auth/API/report logic from that repo.
It only:
  1. Writes config.json (the file the vendored config.py expects to find
     next to itself) based on the env/login the user picks in the UI.
  2. Imports and calls the vendored classes/functions exactly as written.
  3. Captures their stdout, since they were built as CLI tools that
     print() rather than return data, so the output can be shown in
     Streamlit.
  4. Separately builds a DataFrame for an ADDITIONAL interactive/sortable
     view, using the exact same unmodified get_aggregates_by_cube()
     response - this is a wrapper-side addition, not a change to the
     vendored report/stats/health logic itself.
"""

from __future__ import annotations

import io
import os
import sys
import json
import glob
import contextlib
import importlib

import pandas as pd

VENDOR_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "vendor", "atscale_util")
if VENDOR_DIR not in sys.path:
    sys.path.insert(0, VENDOR_DIR)

# Fixed per your environment mapping. This mapping is wrapper-side UI
# convenience - it is NOT part of the vendored repo's logic.
ENV_CONFIG = {
    "Dev":  {"host": "atscale.dev.com",  "organization": "1234567890"},
    "Uat":  {"host": "atscale.uat.com",  "organization": "0987654421"},
    "Prod": {"host": "atscale.prod.com", "organization": "abcd1234"},
}


def _write_config(env: str, username: str, password: str) -> None:
    """Writes config.json next to the vendored config.py, in the exact
    shape that vendored file's load_config()/get_jwt() expect."""
    cfg = ENV_CONFIG[env]
    config_data = {
        "instance_type": "installer",
        "username": username,
        "password": password,
        "host": cfg["host"],
        "organization": cfg["organization"],
    }
    config_path = os.path.join(VENDOR_DIR, "config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config_data, f)


def _capture_stdout(fn, *args, **kwargs) -> str:
    """Runs fn(*args, **kwargs) and returns whatever it printed - the
    vendored classes are CLI tools that print() rather than return data."""
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        fn(*args, **kwargs)
    return buf.getvalue()


def login(env: str, username: str, password: str):
    """
    Writes config.json, then calls the vendored config.get_jwt() /
    AtScaleAPIClient UNMODIFIED to authenticate and pull published projects.
    Returns (client, projects). Raises the real underlying exception on failure.
    """
    _write_config(env, username, password)

    # Fresh import each login so load_config() re-reads the new config.json
    # and a stale JWT from a previous env/login isn't reused.
    import config as atscale_config
    importlib.reload(atscale_config)
    atscale_config.clear_jwt_cache()

    import api_client as atscale_api_client
    importlib.reload(atscale_api_client)

    client = atscale_api_client.AtScaleAPIClient()
    # Exercises the real, unmodified get_jwt() + get_published_projects() logic.
    projects = client.get_published_projects()
    return client, projects


def get_reporter(client):
    from cube_aggregate_reporter import CubeAggregateReporter
    return CubeAggregateReporter(client)


def get_statistics(client):
    from aggregate_statistics import AggregateStatistics
    return AggregateStatistics(client)


def get_health_checker(client):
    from aggregate_health_checker import AggregateHealthChecker
    return AggregateHealthChecker(client)


def run_list_aggregates(client, cube_data: dict) -> str:
    """Calls the real CubeAggregateReporter.list_cube_aggregates() and
    captures its printed report, verbatim."""
    reporter = get_reporter(client)
    return _capture_stdout(reporter.list_cube_aggregates, cube_data)


def run_export_csv(client, cube_data: dict, work_dir: str) -> str | None:
    """
    Calls the real CubeAggregateReporter.export_cube_aggregates_csv()
    UNMODIFIED. That function writes a CSV into the current working
    directory using its own naming pattern
    (aggregates_<CubeName>_<timestamp>.csv). We just temporarily chdir so
    the file lands somewhere we control, then return the newest match.
    """
    os.makedirs(work_dir, exist_ok=True)
    prev_cwd = os.getcwd()
    reporter = get_reporter(client)
    try:
        os.chdir(work_dir)
        reporter.export_cube_aggregates_csv(cube_data)
    finally:
        os.chdir(prev_cwd)

    pattern = os.path.join(work_dir, "aggregates_*.csv")
    matches = sorted(glob.glob(pattern), key=os.path.getmtime)
    return matches[-1] if matches else None


def run_statistics(client, cube_data: dict) -> str:
    """Calls the real AggregateStatistics.show_cube_aggregate_statistics()."""
    stats = get_statistics(client)
    return _capture_stdout(stats.show_cube_aggregate_statistics, cube_data)


def run_health_check(client, cube_data: dict) -> str:
    """Calls the real AggregateHealthChecker.check_cube_aggregate_health()."""
    checker = get_health_checker(client)
    return _capture_stdout(checker.check_cube_aggregate_health, cube_data)


def get_aggregates_dataframe(client, cube_data: dict) -> pd.DataFrame:
    """
    ADDITIONAL interactive view (wrapper-only - not part of the vendored
    repo). Calls the SAME unmodified client.get_aggregates_by_cube() and
    flattens the real response into a DataFrame so it can be sorted and
    filtered in Streamlit, on top of (not instead of) the vendored report.
    """
    response = client.get_aggregates_by_cube(cube_data["project_id"], cube_data["cube_id"])
    aggregates_data = response.get("response", {}).get("data", [])

    rows = []
    for agg in aggregates_data:
        latest_instance = agg.get("latest_instance", {})
        stats = latest_instance.get("stats", {})
        agg_stats = agg.get("stats", {})
        rows.append({
            "cube": cube_data["display"],
            "aggregate_id": agg.get("id", ""),
            "name": agg.get("name", ""),
            "type": agg.get("type", ""),
            "subtype": agg.get("subtype", ""),
            "status": latest_instance.get("status", "unknown"),
            "rows_materialized": stats.get("number_of_rows", 0),
            "build_duration_ms": stats.get("build_duration", 0),
            "query_utilization": agg_stats.get("query_utilization", 0),
            "most_recent_query": agg_stats.get("most_recent_query", ""),
        })
    return pd.DataFrame(rows)
