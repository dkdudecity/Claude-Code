"""
Shared UI building blocks used across every page.
Keeping these in one place is what makes the nav bar, sidebar,
and card styling stay IDENTICAL across all sub-pages.
"""

import streamlit as st


# ---------------------------------------------------------------------------
# GLOBAL CSS  (injected once per page via inject_global_css())
# ---------------------------------------------------------------------------
def inject_global_css() -> None:
    st.markdown(
        """
        <style>
        /* ==========================================================
           PALETTE
           Snowflake Blue #29B5E8 / Snowflake Dark Navy #1B2A47 (official)
           AtScale accent: teal #17B8A6 (approximation - AtScale doesn't
           publish an official hex, this is inspired by their mark)
        ========================================================== */

        /* ---------- General page polish ---------- */
        .block-container {
            padding-top: 1.5rem;
            padding-bottom: 3rem;
            max-width: 1200px;
        }
        body, .stApp {
            background-color: #0B1120;
        }

        /* ---------- Top navigation bar (st.navigation position='top') ---------- */
        [data-testid="stHeader"] {
            width: 100% !important;
        }
        [data-testid="stTopNav"] {
            background: linear-gradient(90deg, #0F1830 0%, #12203D 100%);
            border-bottom: 1px solid #22304D;
            padding: 0.3rem 2rem;
            box-shadow: 0 2px 12px rgba(41, 181, 232, 0.06);
            width: 100% !important;
            max-width: 100% !important;
        }
        [data-testid="stTopNav"] * {
            max-width: 100% !important;
        }
        [data-testid="stTopNav"] a,
        [data-testid="stTopNav"] button,
        header [data-testid="stHeaderActionElements"] ~ div a {
            font-weight: 600 !important;
            font-size: 0.92rem !important;
            color: #93A1C0 !important;
            border-radius: 999px !important;
            padding: 0.4rem 1rem !important;
            margin: 0 0.2rem !important;
            border: 1px solid transparent !important;
            transition: background-color 0.18s ease, color 0.18s ease, border-color 0.18s ease;
        }
        [data-testid="stTopNav"] a:hover {
            background: rgba(41, 181, 232, 0.12) !important;
            color: #6FD8F5 !important;
            border-color: rgba(41, 181, 232, 0.35) !important;
        }
        /* Active/selected tab — gradient pill, Snowflake blue -> AtScale teal */
        [data-testid="stTopNav"] a[aria-current="page"],
        [data-testid="stTopNav"] a[data-selected="true"] {
            background: linear-gradient(90deg, #29B5E8 0%, #17B8A6 100%) !important;
            color: #05131F !important;
            font-weight: 700 !important;
            border-color: transparent !important;
            box-shadow: 0 2px 10px rgba(41, 181, 232, 0.35);
        }

        /* ---------- KPI card ---------- */
        .kpi-card {
            background: linear-gradient(160deg, #121C33 0%, #0F1728 100%);
            border: 1px solid #23304A;
            border-radius: 14px;
            padding: 1.1rem 1.2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.25);
            height: 100%;
        }
        .kpi-label {
            font-size: 0.78rem;
            font-weight: 700;
            color: #7C8AAD;
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-bottom: 0.4rem;
        }
        .kpi-value {
            font-size: 1.95rem;
            font-weight: 700;
            color: #F1F5FB;
            line-height: 1.1;
            background: linear-gradient(90deg, #6FD8F5, #E9EDF5 60%);
            -webkit-background-clip: text;
            background-clip: text;
        }
        .kpi-delta-up   { color: #3DDC97; font-size: 0.85rem; font-weight: 600; }
        .kpi-delta-down { color: #FF6B6B; font-size: 0.85rem; font-weight: 600; }
        .kpi-delta-flat { color: #7C8AAD; font-size: 0.85rem; font-weight: 600; }

        /* ---------- Feature / navigation box (landing page top row) ---------- */
        .feature-box {
            background: linear-gradient(160deg, #121C33 0%, #0E1526 100%);
            border: 1px solid #23304A;
            border-radius: 16px;
            padding: 1.3rem 1.4rem;
            height: 100%;
            transition: box-shadow 0.18s ease, transform 0.18s ease, border-color 0.18s ease;
        }
        .feature-box:hover {
            box-shadow: 0 6px 20px rgba(23, 184, 166, 0.18), 0 6px 20px rgba(41, 181, 232, 0.12);
            transform: translateY(-3px);
            border-color: rgba(41, 181, 232, 0.4);
        }
        .feature-icon {
            font-size: 1.7rem;
            margin-bottom: 0.45rem;
        }
        .feature-title {
            font-size: 1.03rem;
            font-weight: 700;
            color: #F1F5FB;
            margin-bottom: 0.35rem;
        }
        .feature-desc {
            font-size: 0.85rem;
            color: #8D97AF;
            line-height: 1.45;
        }

        /* ---------- Status pill ---------- */
        .pill {
            display: inline-block;
            padding: 0.18rem 0.65rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            letter-spacing: 0.01em;
        }
        .pill-active   { background: rgba(61, 220, 151, 0.15); color: #3DDC97; border: 1px solid rgba(61, 220, 151, 0.35); }
        .pill-pending  { background: rgba(247, 144, 9, 0.15);  color: #F9A94A; border: 1px solid rgba(247, 144, 9, 0.35); }
        .pill-failed   { background: rgba(255, 107, 107, 0.15); color: #FF6B6B; border: 1px solid rgba(255, 107, 107, 0.35); }
        .pill-inactive { background: rgba(141, 151, 175, 0.15); color: #8D97AF; border: 1px solid rgba(141, 151, 175, 0.3); }

        /* ---------- Section headers ---------- */
        .section-header {
            font-size: 1.05rem;
            font-weight: 700;
            color: #F1F5FB;
            margin-top: 1.6rem;
            margin-bottom: 0.6rem;
            padding-left: 0.7rem;
            border-left: 4px solid;
            border-image: linear-gradient(180deg, #29B5E8, #17B8A6) 1;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# SIDEBAR — same filter panel rendered on every page
# ---------------------------------------------------------------------------
def render_sidebar() -> dict:
    """
    Renders the shared sidebar (logo, global filters, connection status).
    Returns a dict of the selected filter values so each page can use them.
    """
    with st.sidebar:
        st.markdown(
            '<div style="font-size:1.15rem; font-weight:800; '
            'background: linear-gradient(90deg, #6FD8F5, #4DEAD1); '
            '-webkit-background-clip:text; background-clip:text; color:transparent;">'
            '🧊 AtScale Ops Console</div>',
            unsafe_allow_html=True,
        )
        st.caption("Internal utility · Snowflake + AtScale")
        st.divider()

        st.markdown("**Filters**")
        org = st.selectbox("Organization", ["default", "sales-org", "finance-org"], key="f_org")
        project = st.selectbox(
            "Project",
            ["All Projects", "Sales Insights", "Internet Sales", "WW Importers", "TPC-DS"],
            key="f_project",
        )
        cube = st.selectbox(
            "Cube / Model",
            ["All Cubes", "Internet Sales Cube", "Returns Cube", "Inventory Cube"],
            key="f_cube",
        )
        time_range = st.select_slider(
            "Time range",
            options=["Last 1h", "Last 24h", "Last 7d", "Last 30d"],
            value="Last 24h",
            key="f_time_range",
        )

        st.divider()
        st.markdown("**Environment**")
        env = st.radio("Target", ["Production", "Staging", "Dev"], horizontal=False, key="f_env")

        st.divider()
        st.markdown("**System status** *(mock)*")
        st.markdown(
            '<span class="pill pill-active">AtScale: Connected</span>',
            unsafe_allow_html=True,
        )
        st.write("")
        st.markdown(
            '<span class="pill pill-active">Snowflake: Connected</span>',
            unsafe_allow_html=True,
        )

        st.divider()
        st.caption("Last refreshed: mock data · not live")
        st.button("🔄 Refresh data", use_container_width=True)

    return {
        "org": org,
        "project": project,
        "cube": cube,
        "time_range": time_range,
        "env": env,
    }


# ---------------------------------------------------------------------------
# REUSABLE COMPONENTS
# ---------------------------------------------------------------------------
def kpi_card(label: str, value: str, delta: str | None = None, delta_dir: str = "flat") -> str:
    """Returns HTML for a single KPI card (use with st.markdown(..., unsafe_allow_html=True))."""
    delta_html = ""
    if delta:
        css_class = {"up": "kpi-delta-up", "down": "kpi-delta-down", "flat": "kpi-delta-flat"}[delta_dir]
        arrow = {"up": "▲", "down": "▼", "flat": "•"}[delta_dir]
        delta_html = f'<div class="{css_class}">{arrow} {delta}</div>'

    return f"""
    <div class="kpi-card">
        <div class="kpi-label">{label}</div>
        <div class="kpi-value">{value}</div>
        {delta_html}
    </div>
    """


def feature_box(icon: str, title: str, desc: str, page_path: str) -> None:
    """Renders a clickable feature box that links to another page in the app."""
    st.markdown(
        f"""
        <div class="feature-box">
            <div class="feature-icon">{icon}</div>
            <div class="feature-title">{title}</div>
            <div class="feature-desc">{desc}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.page_link(page_path, label="Open →", use_container_width=True)
