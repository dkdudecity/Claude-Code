"""
Wrapper-side insight helpers - NOT part of the vendored atscale-aggregate-util
repo. These compute summary KPIs and top-5 lists from the same unmodified
client.get_aggregates_by_cube() response (via get_aggregates_dataframe in
atscale_wrapper.py), purely for Streamlit display.
"""

from __future__ import annotations

import pandas as pd


def _format_ms(ms: float) -> str:
    if ms < 1000:
        return f"{ms:,.0f}ms"
    if ms < 60000:
        return f"{ms/1000:,.1f}s"
    return f"{ms/60000:,.1f}min"


def compute_top5(df: pd.DataFrame) -> dict:
    """Top 5 aggregates by rows, build duration, and query utilization."""
    if df.empty:
        return {"rows": pd.DataFrame(), "build": pd.DataFrame(), "utilization": pd.DataFrame()}
    return {
        "rows": df.nlargest(5, "rows_materialized")[["name", "rows_materialized"]],
        "build": df.nlargest(5, "build_duration_ms")[["name", "build_duration_ms"]],
        "utilization": df.nlargest(5, "query_utilization")[["name", "query_utilization"]],
    }


def compute_cube_summary_kpis(df: pd.DataFrame) -> dict:
    """Top-of-page KPI strip: Active / Total aggregates + Total build time."""
    if df.empty:
        return {"active": 0, "total": 0, "total_build_time": "0ms"}
    status_lower = df["status"].astype(str).str.lower()
    return {
        "active": int((status_lower == "active").sum()),
        "total": len(df),
        "total_build_time": _format_ms(df["build_duration_ms"].sum()),
    }


def compute_statistics_kpis(df: pd.DataFrame) -> dict | None:
    """Values used to replace the statistics text dump with KPI cards."""
    if df.empty:
        return None
    status_lower = df["status"].astype(str).str.lower()
    return {
        "total_aggregates": len(df),
        "active": int((status_lower == "active").sum()),
        "total_rows": int(df["rows_materialized"].sum()),
        "avg_build_time": _format_ms(df["build_duration_ms"].mean()),
        "avg_query_utilization": round(float(df["query_utilization"].mean()), 1),
    }


def compute_health_kpis(df: pd.DataFrame) -> dict | None:
    """Lightweight health score/issue counts, same scoring idea as a health check."""
    if df.empty:
        return None
    status_lower = df["status"].astype(str).str.lower()
    issues = int((~status_lower.isin(["active"])).sum())
    zero_rows = int((df["rows_materialized"] == 0).sum())
    total = len(df)
    score = max(0, round(100 - (issues / total * 50) - (zero_rows / total * 25))) if total else 0
    return {"health_score": score, "issues": issues, "zero_row_aggs": zero_rows, "total_aggregates": total}
