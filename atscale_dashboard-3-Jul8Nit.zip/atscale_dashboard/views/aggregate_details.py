import os

import pandas as pd
import streamlit as st

from utils.ui import inject_global_css, render_sidebar, kpi_card
from utils.atscale_wrapper import (
    ENV_CONFIG,
    login,
    run_list_aggregates,
    run_export_csv,
    run_health_check,
    get_aggregates_dataframe,
)
from utils.aggregate_insights import (
    compute_top5,
    compute_cube_summary_kpis,
    compute_statistics_kpis,
    compute_health_kpis,
)

inject_global_css()
render_sidebar()

st.title("📊 Aggregate Details")
st.caption(
    "Wraps the real, unmodified atscale-aggregate-util code "
    "(vendor/atscale_util/) — auth, API calls, and report logic are "
    "exactly as authored upstream."
)

ss = st.session_state
ss.setdefault("as_env", None)
ss.setdefault("as_authenticated", False)
ss.setdefault("as_client", None)
ss.setdefault("as_projects", None)
ss.setdefault("as_username", None)

WORK_DIR = os.path.join("/home/claude", "atscale_csv_exports")


def _cube_data(catalog_obj, cube_obj) -> dict:
    return {
        "project_id": catalog_obj["id"],
        "cube_id": cube_obj["id"],
        "display": f"{catalog_obj.get('name', catalog_obj['id'])} / {cube_obj.get('name', cube_obj['id'])}",
    }


def _show_console_block(text: str, height: int = 350) -> None:
    """Non-wrapping, monospace, scrollable block for vendored CLI output."""
    with st.container(height=height, border=True):
        st.code(text or "(no output)", language=None)


def _kpi_row(cards: list[tuple]) -> None:
    """cards: list of (label, value, delta, delta_dir) tuples -> one row of KPI boxes."""
    cols = st.columns(len(cards))
    for col, (label, value, delta, delta_dir) in zip(cols, cards):
        with col:
            st.markdown(kpi_card(label, value, delta, delta_dir), unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# STEP 1 — Environment picker
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">1. Select Environment</div>', unsafe_allow_html=True)

env_choice = st.selectbox(
    "Environment",
    options=list(ENV_CONFIG.keys()),
    index=None,
    placeholder="Choose Dev / Uat / Prod...",
    key="env_selectbox",
)

if env_choice and env_choice != ss.as_env:
    ss.as_env = env_choice
    ss.as_authenticated = False
    ss.as_client = None
    ss.as_projects = None

if env_choice:
    cfg = ENV_CONFIG[env_choice]
    st.caption(f"Host: `{cfg['host']}` · Organization: `{cfg['organization']}` · Instance type: `installer`")

# ---------------------------------------------------------------------------
# STEP 2 — Login (hidden after success)
# ---------------------------------------------------------------------------
if env_choice and not ss.as_authenticated:
    st.markdown('<div class="section-header">2. Login</div>', unsafe_allow_html=True)
    with st.form("atscale_login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("🔐 Login", type="primary")

    if submitted:
        with st.spinner(f"Authenticating against {ENV_CONFIG[env_choice]['host']}..."):
            try:
                client, projects = login(env_choice, username, password)
            except Exception as exc:  # noqa: BLE001 - surface the real underlying error
                st.error(f"Login failed: {exc}")
            else:
                ss.as_authenticated = True
                ss.as_client = client
                ss.as_projects = projects
                ss.as_username = username
                st.rerun()

# ---------------------------------------------------------------------------
# Authenticated area
# ---------------------------------------------------------------------------
if ss.as_authenticated and ss.as_client:
    c1, c2 = st.columns([5, 1])
    with c1:
        st.success(f"Logged in as **{ss.as_username}** to **{env_choice}** ({ENV_CONFIG[env_choice]['host']})")
    with c2:
        if st.button("Logout", use_container_width=True):
            for key in ("as_authenticated", "as_client", "as_projects", "as_username"):
                ss[key] = None if key != "as_authenticated" else False
            st.rerun()

    # -- STEP 3: Cube picker (single cube only) ------------------------------
    st.markdown('<div class="section-header">3. Select Cube</div>', unsafe_allow_html=True)

    all_projects = ss.as_projects or []
    catalog_options = {p.get("name", p.get("id", "Unknown")): p for p in all_projects}
    catalog_name = st.selectbox("Project / Catalog", options=list(catalog_options.keys()) or ["(none published)"])

    catalog = catalog_options.get(catalog_name)
    cubes = catalog.get("cubes", []) if catalog else []
    cube_names = [c.get("name", c.get("id", "Unknown")) for c in cubes]
    cube_choice = st.selectbox("Cube", options=cube_names or ["(no cubes published)"])

    fetch = st.button("📥 Load Aggregate Data", type="primary", disabled=catalog is None)

    st.markdown("**Bulk export**")
    all_cubes_export = st.button(
        "📦 Download ALL Projects / ALL Cubes Aggregate Report (single CSV)",
        use_container_width=True,
    )

    if fetch and catalog:
        cube_obj = next(c for c in cubes if c.get("name", c.get("id")) == cube_choice)
        ss.as_selected_cube = _cube_data(catalog, cube_obj)

    # -- Bulk export: loops EVERY project and EVERY cube in the org, calls the
    #    real unmodified export function per cube, concatenates all real rows
    #    into ONE combined CSV. ------------------------------------------------
    if all_cubes_export:
        combined_rows = []
        total_cubes = sum(len(p.get("cubes", [])) for p in all_projects)
        progress = st.progress(0, text="Starting...")
        done = 0
        for proj in all_projects:
            for cube_obj in proj.get("cubes", []):
                cd = _cube_data(proj, cube_obj)
                progress.progress(min(done / max(total_cubes, 1), 1.0), text=f"Exporting {cd['display']}...")
                try:
                    csv_path = run_export_csv(ss.as_client, cd, WORK_DIR)
                    if csv_path:
                        df = pd.read_csv(csv_path)
                        df.insert(0, "cube", cd["display"])
                        combined_rows.append(df)
                except Exception as exc:  # noqa: BLE001
                    st.warning(f"Skipped {cd['display']}: {exc}")
                done += 1
        progress.progress(1.0, text="Done")

        if combined_rows:
            combined = pd.concat(combined_rows, ignore_index=True)
            st.success(f"Combined {total_cubes} cube(s) across {len(all_projects)} project(s) into one report ({len(combined)} aggregate rows).")
            st.download_button(
                "⬇️ Download Combined All-Projects/All-Cubes CSV",
                data=combined.to_csv(index=False).encode("utf-8"),
                file_name=f"aggregate_report_ALL_{env_choice}.csv",
                mime="text/csv",
                type="primary",
                key="all_cubes_csv_dl",
            )
        else:
            st.info("No aggregates found across any project/cube.")

    # -- STEP 4: KPI strip for the selected cube (right below selection) -----
    if ss.get("as_selected_cube"):
        cd = ss.as_selected_cube

        with st.spinner(f"Pulling aggregate data for {cd['display']}..."):
            try:
                df = get_aggregates_dataframe(ss.as_client, cd)
            except Exception:  # noqa: BLE001
                df = pd.DataFrame()

        summary = compute_cube_summary_kpis(df)
        st.markdown('<div class="section-header">Selected Cube — Aggregate Metadata</div>', unsafe_allow_html=True)
        _kpi_row([
            ("Active Aggregates", str(summary["active"]), None, "flat"),
            ("Total Aggregates", str(summary["total"]), None, "flat"),
            ("Total Build Time", summary["total_build_time"], "sum of all aggregates", "flat"),
        ])

        # -- Aggregate Report (vendored CLI output + CSV) --------------------
        st.markdown('<div class="section-header">Aggregate Report</div>', unsafe_allow_html=True)
        try:
            report_text = run_list_aggregates(ss.as_client, cd)
        except Exception as exc:  # noqa: BLE001
            report_text = f"Error: {exc}"
        try:
            csv_path = run_export_csv(ss.as_client, cd, WORK_DIR)
        except Exception:  # noqa: BLE001
            csv_path = None

        st.markdown("**Original CLI output (unmodified `CubeAggregateReporter`)**")
        _show_console_block(report_text, height=350)

        if csv_path:
            with open(csv_path, "rb") as f:
                st.download_button(
                    "⬇️ Export to CSV (this cube — real file, real fieldnames)",
                    data=f.read(),
                    file_name=os.path.basename(csv_path),
                    mime="text/csv",
                    type="primary",
                    key="report_csv_dl",
                )

        # -- Top 5 Insights (replaces the old interactive table) -------------
        st.markdown('<div class="section-header">Top 5 Insights</div>', unsafe_allow_html=True)
        top5 = compute_top5(df)
        t1, t2, t3 = st.columns(3)
        with t1:
            st.markdown("**By Rows**")
            st.dataframe(top5["rows"], use_container_width=True, hide_index=True)
        with t2:
            st.markdown("**By Build Duration (ms)**")
            st.dataframe(top5["build"], use_container_width=True, hide_index=True)
        with t3:
            st.markdown("**By Query Utilization**")
            st.dataframe(top5["utilization"], use_container_width=True, hide_index=True)

        # -- Aggregate Statistics — collapsible, KPI boxes instead of text ----
        with st.expander("📈 Aggregate Statistics", expanded=False):
            stats_kpis = compute_statistics_kpis(df)
            if stats_kpis is None:
                st.info("No statistics to show for this cube.")
            else:
                _kpi_row([
                    ("Total Aggregates", str(stats_kpis["total_aggregates"]), None, "flat"),
                    ("Active", str(stats_kpis["active"]), None, "up"),
                    ("Total Rows", f"{stats_kpis['total_rows']:,}", None, "flat"),
                    ("Avg Build Time", stats_kpis["avg_build_time"], None, "flat"),
                    ("Avg Query Utilization", str(stats_kpis["avg_query_utilization"]), None, "flat"),
                ])
                st.download_button(
                    "⬇️ Export Statistics (CSV)",
                    data=pd.DataFrame([stats_kpis]).to_csv(index=False).encode("utf-8"),
                    file_name=f"aggregate_statistics_{cd['display'].replace(' ', '_').replace('/', '-')}.csv",
                    mime="text/csv",
                    key="stats_csv_dl",
                )

        # -- Aggregate Health Check — collapsible, KPI row + vendored text ----
        with st.expander("🩺 Aggregate Health Check", expanded=False):
            health_kpis = compute_health_kpis(df)
            if health_kpis is not None:
                _kpi_row([
                    ("Health Score", f"{health_kpis['health_score']}/100",
                     None, "up" if health_kpis["health_score"] >= 80 else "down"),
                    ("Issues", str(health_kpis["issues"]), None, "down" if health_kpis["issues"] else "flat"),
                    ("Zero-Row Aggregates", str(health_kpis["zero_row_aggs"]), None, "flat"),
                    ("Total Aggregates", str(health_kpis["total_aggregates"]), None, "flat"),
                ])

            try:
                health_text = run_health_check(ss.as_client, cd)
            except Exception as exc:  # noqa: BLE001
                health_text = f"Error: {exc}"
            st.markdown("**Original CLI output (unmodified `AggregateHealthChecker`)**")
            _show_console_block(health_text, height=380)
            st.download_button(
                "⬇️ Export Health Check (.txt — exact console output)",
                data=health_text.encode("utf-8"),
                file_name=f"aggregate_health_{cd['display'].replace(' ', '_').replace('/', '-')}.txt",
                mime="text/plain",
                key="health_txt_dl",
            )

elif not env_choice:
    st.info("Pick an environment above to begin.")
