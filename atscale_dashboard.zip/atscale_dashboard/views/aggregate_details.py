import streamlit as st

from utils.ui import inject_global_css, render_sidebar
from utils.mock_data import get_aggregates_table

inject_global_css()
filters = render_sidebar()

st.title("📊 Aggregate Details")
st.caption("Browse aggregate instances by definition, status, batch, and build stats. (Mocked — wire up the aggregate-instances endpoint here.)")

df = get_aggregates_table()

st.markdown('<div class="section-header">Filters</div>', unsafe_allow_html=True)
f1, f2, f3 = st.columns(3)
with f1:
    cube_filter = st.multiselect("Cube", sorted(df["cube"].unique()), default=list(df["cube"].unique()))
with f2:
    status_filter = st.multiselect("Status", sorted(df["status"].unique()), default=list(df["status"].unique()))
with f3:
    min_rows = st.number_input("Min rows materialized", min_value=0, value=0, step=1000)

filtered = df[
    df["cube"].isin(cube_filter)
    & df["status"].isin(status_filter)
    & (df["rows_materialized"] >= min_rows)
]

st.markdown('<div class="section-header">Status Breakdown</div>', unsafe_allow_html=True)
status_counts = filtered["status"].value_counts()
st.bar_chart(status_counts, height=220)

st.markdown('<div class="section-header">Aggregate Instances</div>', unsafe_allow_html=True)
st.dataframe(
    filtered,
    use_container_width=True,
    hide_index=True,
    column_config={
        "rows_materialized": st.column_config.NumberColumn("Rows", format="%d"),
        "build_duration_sec": st.column_config.NumberColumn("Build Time (s)"),
        "last_build": st.column_config.DatetimeColumn("Last Build", format="MMM D, HH:mm"),
    },
)

st.caption(f"Showing {len(filtered)} of {len(df)} aggregate instances.")
