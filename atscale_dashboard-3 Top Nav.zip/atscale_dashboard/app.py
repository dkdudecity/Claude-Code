"""
Entry point for the AtScale Ops Console.

Run with:
    streamlit run app.py

Structure:
    app.py                     <- this file (nav shell only)
    views/landing.py           <- landing page (KPIs + feature boxes)
    views/query_sql.py         <- sub-page: Query & SQL Explorer
    views/trigger_aggregates.py<- sub-page: Trigger Aggregates
    views/aggregate_details.py <- sub-page: Aggregate Details
    utils/ui.py                <- shared CSS, sidebar, KPI/feature components
    utils/mock_data.py         <- mock data generators (swap for real API calls)

st.navigation() below is what keeps the SAME top nav bar on every page —
each page file just calls render_sidebar() + inject_global_css() itself,
so styling and filters stay consistent without duplicating layout code.
"""

import streamlit as st

st.set_page_config(
    page_title="AtScale Ops Console",
    page_icon="🧊",
    layout="wide",
    initial_sidebar_state="expanded",
)

landing_page = st.Page("views/landing.py", title="Home", icon="🏠", default=True)
query_sql_page = st.Page("views/query_sql.py", title="Query & SQL Explorer", icon="🔍")
trigger_agg_page = st.Page("views/trigger_aggregates.py", title="Trigger Aggregates", icon="⚙️")
agg_details_page = st.Page("views/aggregate_details.py", title="Aggregate Details", icon="📊")

# Flat list (no group dict) -> renders as one consistent row of tabs,
# not split into separate labeled sections.
pg = st.navigation(
    [landing_page, query_sql_page, trigger_agg_page, agg_details_page],
    position="top",
)

pg.run()
