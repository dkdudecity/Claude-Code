import streamlit as st

from utils.ui import inject_global_css, render_sidebar, kpi_card, feature_box
from utils.mock_data import (
    get_kpi_summary,
    get_query_volume_timeseries,
    get_aggregates_table,
)

inject_global_css()
filters = render_sidebar()

st.title("🧊 AtScale Ops Console")
st.caption(
    f"Org: **{filters['org']}** · Project: **{filters['project']}** · "
    f"Cube: **{filters['cube']}** · Window: **{filters['time_range']}** · "
    f"Env: **{filters['env']}**"
)

# ---------------------------------------------------------------------------
# TOP ROW — feature boxes, one per sub-page
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">Tools</div>', unsafe_allow_html=True)

box1, box2, box3 = st.columns(3, gap="medium")
with box1:
    feature_box(
        icon="🔍",
        title="Query & SQL Explorer",
        desc="Pick a model/query and pull the AtScale-generated SQL. Optionally run it against Snowflake.",
        page_path="views/query_sql.py",
    )
with box2:
    feature_box(
        icon="⚙️",
        title="Trigger Aggregates",
        desc="Kick off an initial build or rebuild for pending aggregate batches on a published cube.",
        page_path="views/trigger_aggregates.py",
    )
with box3:
    feature_box(
        icon="📊",
        title="Aggregate Details",
        desc="Browse aggregate instances by status, build duration, and row counts across cubes.",
        page_path="views/aggregate_details.py",
    )

# ---------------------------------------------------------------------------
# KPI STRIP 1 — Aggregates
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">Aggregate Health</div>', unsafe_allow_html=True)

kpis = get_kpi_summary()
c1, c2, c3, c4 = st.columns(4, gap="medium")
with c1:
    st.markdown(kpi_card("Total Aggregates", f"{kpis['total_aggregates']:,}"), unsafe_allow_html=True)
with c2:
    st.markdown(
        kpi_card("Active", f"{kpis['active_aggregates']:,}", "83% of total", "up"),
        unsafe_allow_html=True,
    )
with c3:
    st.markdown(
        kpi_card("Pending / In-Progress", f"{kpis['pending_aggregates']:,}", "building now", "flat"),
        unsafe_allow_html=True,
    )
with c4:
    st.markdown(
        kpi_card("Failed", f"{kpis['failed_aggregates']:,}", "needs attention", "down"),
        unsafe_allow_html=True,
    )

# ---------------------------------------------------------------------------
# KPI STRIP 2 — Queries
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">Query Activity</div>', unsafe_allow_html=True)

d1, d2, d3, d4 = st.columns(4, gap="medium")
with d1:
    st.markdown(
        kpi_card("Total Queries (24h)", f"{kpis['total_queries_24h']:,}", "+6.4% vs prior day", "up"),
        unsafe_allow_html=True,
    )
with d2:
    st.markdown(
        kpi_card("Failed Queries (24h)", f"{kpis['failed_queries_24h']:,}", "0.7% failure rate", "down"),
        unsafe_allow_html=True,
    )
with d3:
    st.markdown(
        kpi_card("Avg Query Duration", f"{kpis['avg_query_duration_ms']:,} ms", "-4% vs prior day", "up"),
        unsafe_allow_html=True,
    )
with d4:
    st.markdown(
        kpi_card("Max Subquery Wait", f"{kpis['max_subquery_wait_ms']:,} ms", "warehouse contention", "flat"),
        unsafe_allow_html=True,
    )

# ---------------------------------------------------------------------------
# CHART — query volume trend
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">Query Volume — Last 7 Days</div>', unsafe_allow_html=True)
qv = get_query_volume_timeseries()
st.line_chart(qv.set_index("timestamp")["query_count"], height=260)

# ---------------------------------------------------------------------------
# TABLE — aggregates snapshot
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">Aggregates Snapshot</div>', unsafe_allow_html=True)

agg_df = get_aggregates_table()
status_filter = st.multiselect(
    "Filter by status",
    options=sorted(agg_df["status"].unique()),
    default=list(agg_df["status"].unique()),
)
st.dataframe(
    agg_df[agg_df["status"].isin(status_filter)],
    use_container_width=True,
    hide_index=True,
    column_config={
        "rows_materialized": st.column_config.NumberColumn("Rows", format="%d"),
        "build_duration_sec": st.column_config.NumberColumn("Build Time (s)"),
        "last_build": st.column_config.DatetimeColumn("Last Build", format="MMM D, HH:mm"),
    },
)
