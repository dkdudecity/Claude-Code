import time

import streamlit as st

from utils.ui import inject_global_css, render_sidebar
from utils.mock_data import get_pending_aggregate_batches

inject_global_css()
filters = render_sidebar()

st.title("⚙️ Trigger Aggregate Builds")
st.caption("Trigger an initial build or rebuild for aggregates on a published cube. (Mocked — wire up the aggregate-batch endpoint here.)")

st.markdown('<div class="section-header">Select cube</div>', unsafe_allow_html=True)
col1, col2 = st.columns([2, 1])
with col1:
    cube = st.selectbox(
        "Cube",
        ["Internet Sales Cube", "Returns Cube", "Inventory Cube", "Finance Cube"],
    )
with col2:
    build_type = st.radio("Build type", ["Full rebuild", "Incremental"], horizontal=True)

confirm = st.checkbox("I have Manage Aggregates permission and confirm this trigger action.")
trigger = st.button("🚀 Trigger Build", type="primary", disabled=not confirm)

if trigger:
    with st.spinner(f"Triggering {build_type.lower()} for {cube} (mocked)..."):
        time.sleep(1.2)
    st.success(f"Build triggered for **{cube}** — batch queued. Track progress below.")
    st.toast("Aggregate batch triggered", icon="✅")

st.markdown('<div class="section-header">Pending Batches</div>', unsafe_allow_html=True)
batches = get_pending_aggregate_batches()

for _, row in batches.iterrows():
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns([2, 1.2, 1, 1])
        c1.markdown(f"**{row['cube']}**")
        status_class = {
            "active": "pill-active",
            "pending": "pill-pending",
            "failed": "pill-failed",
        }.get(row["last_build_status"], "pill-inactive")
        c2.markdown(
            f'<span class="pill {status_class}">{row["last_build_status"]}</span>',
            unsafe_allow_html=True,
        )
        c3.markdown(f"{row['aggregates_in_batch']} aggs")
        c4.button("Trigger", key=f"trigger_{row['cube']}", use_container_width=True)
