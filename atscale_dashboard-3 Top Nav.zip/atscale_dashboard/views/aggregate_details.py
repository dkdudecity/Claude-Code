import streamlit as st
import pandas as pd

from utils.ui import inject_global_css, render_sidebar
from utils.atscale_client import ENV_CONFIG, AtScaleAPIClient, get_jwt_token, AtScaleAuthError
from utils.aggregate_reporter import list_cube_aggregates, list_all_cube_aggregates, export_to_csv_bytes
from utils.aggregate_statistics import compute_statistics_table
from utils.aggregate_health import compute_health_table, compute_all_issues

inject_global_css()
render_sidebar()

st.title("📊 Aggregate Details")
st.caption("Real AtScale connection — env → login → cube → report / statistics / health.")

# ---------------------------------------------------------------------------
# Session state defaults
# ---------------------------------------------------------------------------
ss = st.session_state
ss.setdefault("as_env", None)
ss.setdefault("as_authenticated", False)
ss.setdefault("as_client", None)
ss.setdefault("as_projects", None)
ss.setdefault("as_username", None)

# ---------------------------------------------------------------------------
# STEP 1 — Environment picker (host + org are derived, not typed)
# ---------------------------------------------------------------------------
st.markdown('<div class="section-header">1. Select Environment</div>', unsafe_allow_html=True)

env_choice = st.selectbox(
    "Environment",
    options=list(ENV_CONFIG.keys()),
    index=None,
    placeholder="Choose Dev / Uat / Prod...",
    key="env_selectbox",
)

if env_choice and env_choice != ss.as_env:
    # Env changed -> reset any prior session so old cube data doesn't leak across envs
    ss.as_env = env_choice
    ss.as_authenticated = False
    ss.as_client = None
    ss.as_projects = None

if env_choice:
    cfg = ENV_CONFIG[env_choice]
    st.caption(f"Host: `{cfg['host']}` · Organization: `{cfg['org']}` · Instance type: `installer`")

# ---------------------------------------------------------------------------
# STEP 2 — Login (only shown once an env is picked, hidden after success)
# ---------------------------------------------------------------------------
if env_choice and not ss.as_authenticated:
    st.markdown('<div class="section-header">2. Login</div>', unsafe_allow_html=True)
    with st.form("atscale_login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("🔐 Login", type="primary")

    if submitted:
        cfg = ENV_CONFIG[env_choice]
        with st.spinner(f"Authenticating against {cfg['host']}..."):
            try:
                token = get_jwt_token(
                    host=cfg["host"],
                    org=cfg["org"],
                    username=username,
                    password=password,
                )
                client = AtScaleAPIClient(host=cfg["host"], org=cfg["org"], token=token)
                projects = client.get_published_projects()
            except AtScaleAuthError as exc:
                st.error(f"Login failed: {exc}")
            except Exception as exc:  # noqa: BLE001 - surface any network/parse error to the user
                st.error(f"Unexpected error while connecting: {exc}")
            else:
                ss.as_authenticated = True
                ss.as_client = client
                ss.as_projects = projects
                ss.as_username = username
                st.rerun()

# ---------------------------------------------------------------------------
# Authenticated area — login form is hidden from here down
# ---------------------------------------------------------------------------
if ss.as_authenticated and ss.as_client:
    c1, c2 = st.columns([5, 1])
    with c1:
        st.success(f"Logged in as **{ss.as_username}** to **{env_choice}** ({ENV_CONFIG[env_choice]['host']})")
    with c2:
        if st.button("Logout", use_container_width=True):
            for key in ("as_authenticated", "as_client", "as_projects", "as_username"):
                ss[key] = None if key != "as_authenticated" else False
            st.rerun()

    # -- STEP 3: Cube picker (with "All Cubes" option) --------------------
    st.markdown('<div class="section-header">3. Select Cube</div>', unsafe_allow_html=True)

    projects = ss.as_projects or []
    catalog_options = {p["catalog_name"]: p for p in projects}
    catalog_name = st.selectbox("Project / Catalog", options=list(catalog_options.keys()) or ["(none published)"])

    catalog = catalog_options.get(catalog_name)
    cube_names = ["All Cubes"] + ([c["cube_name"] for c in catalog["cubes"]] if catalog else [])
    cube_choice = st.selectbox("Cube", options=cube_names)

    fetch = st.button("📥 Load Aggregate Data", type="primary", disabled=catalog is None)

    if fetch and catalog:
        with st.spinner("Pulling aggregate instances from AtScale..."):
            try:
                if cube_choice == "All Cubes":
                    cube_dfs = {
                        c["cube_name"]: list_cube_aggregates(ss.as_client, catalog["catalog_id"], c["cube_name"], c["model_id"])
                        for c in catalog["cubes"]
                    }
                    combined_df = list_all_cube_aggregates(ss.as_client, catalog["catalog_id"], catalog["cubes"])
                else:
                    model_id = next(c["model_id"] for c in catalog["cubes"] if c["cube_name"] == cube_choice)
                    single_df = list_cube_aggregates(ss.as_client, catalog["catalog_id"], cube_choice, model_id)
                    cube_dfs = {cube_choice: single_df}
                    combined_df = single_df
            except Exception as exc:  # noqa: BLE001
                st.error(f"Failed to load aggregates: {exc}")
            else:
                ss.as_cube_dfs = cube_dfs
                ss.as_combined_df = combined_df
                ss.as_selected_cube = cube_choice

    # -- STEP 4: Aggregate report (list + CSV export) ----------------------
    if ss.get("as_combined_df") is not None:
        st.markdown('<div class="section-header">Aggregate Report</div>', unsafe_allow_html=True)
        report_df = ss.as_combined_df

        if report_df.empty:
            st.info("No aggregates found for this selection.")
        else:
            f1, f2 = st.columns(2)
            with f1:
                status_filter = st.multiselect(
                    "Filter by status", sorted(report_df["status"].dropna().unique()),
                    default=list(report_df["status"].dropna().unique()), key="report_status_filter",
                )
            with f2:
                cube_filter = st.multiselect(
                    "Filter by cube", sorted(report_df["cube"].dropna().unique()),
                    default=list(report_df["cube"].dropna().unique()), key="report_cube_filter",
                ) if "cube" in report_df else []

            view = report_df[report_df["status"].isin(status_filter)]
            if "cube" in report_df:
                view = view[view["cube"].isin(cube_filter)]

            st.dataframe(view, use_container_width=True, hide_index=True)
            st.caption("Tip: click a column header to sort. Use the filters above to narrow the view before exporting.")

            st.download_button(
                "⬇️ Export Aggregates to CSV",
                data=export_to_csv_bytes(view),
                file_name=f"aggregates_{env_choice}_{cube_choice.replace(' ', '_')}.csv",
                mime="text/csv",
                type="primary",
            )

        # -- STEP 5: Aggregate Statistics -----------------------------------
        st.markdown('<div class="section-header">Aggregate Statistics</div>', unsafe_allow_html=True)
        stats_table = compute_statistics_table(ss.as_cube_dfs)

        if stats_table.empty:
            st.info("No statistics to show for this selection.")
        else:
            sort_col = st.selectbox(
                "Sort statistics by", options=list(stats_table.columns), index=0, key="stats_sort_col"
            )
            sort_dir = st.radio("Direction", ["Descending", "Ascending"], horizontal=True, key="stats_sort_dir")
            stats_sorted = stats_table.sort_values(sort_col, ascending=(sort_dir == "Ascending"))

            st.dataframe(stats_sorted, use_container_width=True, hide_index=True, height=min(400, 45 + 35 * len(stats_sorted)))
            st.download_button(
                "⬇️ Export Statistics to CSV",
                data=export_to_csv_bytes(stats_sorted),
                file_name=f"aggregate_statistics_{env_choice}.csv",
                mime="text/csv",
            )

        # -- STEP 6: Aggregate Health Check ----------------------------------
        st.markdown('<div class="section-header">Aggregate Health Check</div>', unsafe_allow_html=True)
        health_table = compute_health_table(ss.as_cube_dfs)

        if health_table.empty:
            st.info("No health data to show for this selection.")
        else:
            h_sort_col = st.selectbox(
                "Sort health summary by", options=list(health_table.columns), index=1, key="health_sort_col"
            )
            h_sort_dir = st.radio("Direction", ["Descending", "Ascending"], horizontal=True, key="health_sort_dir")
            health_sorted = health_table.sort_values(h_sort_col, ascending=(h_sort_dir == "Ascending"))

            st.dataframe(health_sorted, use_container_width=True, hide_index=True, height=min(400, 45 + 35 * len(health_sorted)))
            st.download_button(
                "⬇️ Export Health Summary to CSV",
                data=export_to_csv_bytes(health_sorted),
                file_name=f"aggregate_health_{env_choice}.csv",
                mime="text/csv",
            )

            with st.expander("🔎 Drill into individual issues"):
                issues_df = compute_all_issues(ss.as_cube_dfs)
                if issues_df.empty:
                    st.success("No individual issues detected across the selected cube(s).")
                else:
                    issue_cube_filter = st.multiselect(
                        "Filter by cube", sorted(issues_df["cube"].unique()),
                        default=list(issues_df["cube"].unique()), key="issue_cube_filter",
                    )
                    issues_view = issues_df[issues_df["cube"].isin(issue_cube_filter)]
                    st.dataframe(issues_view, use_container_width=True, hide_index=True)
                    st.download_button(
                        "⬇️ Export Issues to CSV",
                        data=export_to_csv_bytes(issues_view),
                        file_name=f"aggregate_issues_{env_choice}.csv",
                        mime="text/csv",
                    )
elif not env_choice:
    st.info("Pick an environment above to begin.")
