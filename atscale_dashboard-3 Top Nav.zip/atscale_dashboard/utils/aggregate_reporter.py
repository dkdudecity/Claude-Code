"""
Aggregate reporting — adapted from cube_aggregate_reporter.py.
Produces a DataFrame per cube (or combined across all cubes) and a
CSV export helper for the "Export Aggregates to CSV" button.
"""

from __future__ import annotations

import pandas as pd

from utils.atscale_client import AtScaleAPIClient


def list_cube_aggregates(client: AtScaleAPIClient, catalog_id: str, cube_name: str, model_id: str) -> pd.DataFrame:
    """Fetch aggregates for a single cube, tagged with the cube name."""
    df = client.get_aggregates_by_cube(catalog_id, model_id)
    if df.empty:
        return df
    df.insert(0, "cube", cube_name)
    return df


def list_all_cube_aggregates(client: AtScaleAPIClient, catalog_id: str, cubes: list[dict]) -> pd.DataFrame:
    """Loop across every cube in the catalog and return one combined DataFrame."""
    frames = []
    for cube in cubes:
        df = list_cube_aggregates(client, catalog_id, cube["cube_name"], cube["model_id"])
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def export_to_csv_bytes(df: pd.DataFrame) -> bytes:
    """Serializes the CURRENT (already filtered) view to CSV bytes for download."""
    return df.to_csv(index=False).encode("utf-8")
