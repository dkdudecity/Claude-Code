"""
Shared UI building blocks used across every page.
Keeping these in one place is what makes the nav bar, sidebar,
and card styling stay IDENTICAL across all sub-pages.
"""

import streamlit as st


# ---------------------------------------------------------------------------
# GLOBAL CSS  (injected once per page via inject_global_css())
# ---------------------------------------------------------------------------
def inject_global_css() -> None:
    st.markdown(
        """
        <style>
        /* ---------- General page polish ---------- */
        .block-container {
            padding-top: 1.5rem;
            padding-bottom: 3rem;
            max-width: 1200px;
        }

        /* ---------- Top navigation bar (st.navigation position='top') ---------- */
        [data-testid="stTopNav"] {
            background-color: #FFFFFF;
            border-bottom: 1px solid #E6E9EF;
            padding: 0.25rem 1rem;
        }
        /* Individual tab items — same look/spacing on every page since this
           CSS block is injected once per page via inject_global_css(). */
        [data-testid="stTopNav"] a,
        [data-testid="stTopNav"] button,
        header [data-testid="stHeaderActionElements"] ~ div a {
            font-weight: 600 !important;
            font-size: 0.92rem !important;
            color: #667085 !important;
            border-radius: 8px !important;
            padding: 0.35rem 0.8rem !important;
            margin: 0 0.15rem !important;
            transition: background-color 0.15s ease, color 0.15s ease;
        }
        [data-testid="stTopNav"] a:hover {
            background-color: #F2F6FF !important;
            color: #2E6FF2 !important;
        }
        /* Active/selected tab — Streamlit marks this with aria-current or a
           distinct data attribute depending on version; both are covered. */
        [data-testid="stTopNav"] a[aria-current="page"],
        [data-testid="stTopNav"] a[data-selected="true"] {
            background-color: #EAF1FF !important;
            color: #2E6FF2 !important;
            border-bottom: 2px solid #2E6FF2 !important;
        }

        /* ---------- KPI card ---------- */
        .kpi-card {
            background: #FFFFFF;
            border: 1px solid #E6E9EF;
            border-radius: 12px;
            padding: 1.1rem 1.2rem;
            box-shadow: 0 1px 2px rgba(16, 24, 40, 0.04);
            height: 100%;
        }
        .kpi-label {
            font-size: 0.80rem;
            font-weight: 600;
            color: #667085;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            margin-bottom: 0.35rem;
        }
        .kpi-value {
            font-size: 1.9rem;
            font-weight: 700;
            color: #1A1F36;
            line-height: 1.1;
        }
        .kpi-delta-up   { color: #12B76A; font-size: 0.85rem; font-weight: 600; }
        .kpi-delta-down { color: #F04438; font-size: 0.85rem; font-weight: 600; }
        .kpi-delta-flat { color: #667085; font-size: 0.85rem; font-weight: 600; }

        /* ---------- Feature / navigation box (landing page top row) ---------- */
        .feature-box {
            background: linear-gradient(180deg, #FFFFFF 0%, #F8FAFF 100%);
            border: 1px solid #E6E9EF;
            border-radius: 14px;
            padding: 1.25rem 1.3rem;
            height: 100%;
            transition: box-shadow 0.15s ease, transform 0.15s ease;
        }
        .feature-box:hover {
            box-shadow: 0 4px 14px rgba(46, 111, 242, 0.12);
            transform: translateY(-2px);
        }
        .feature-icon {
            font-size: 1.6rem;
            margin-bottom: 0.4rem;
        }
        .feature-title {
            font-size: 1.02rem;
            font-weight: 700;
            color: #1A1F36;
            margin-bottom: 0.3rem;
        }
        .feature-desc {
            font-size: 0.85rem;
            color: #667085;
            line-height: 1.4;
        }

        /* ---------- Status pill ---------- */
        .pill {
            display: inline-block;
            padding: 0.15rem 0.6rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .pill-active   { background: #ECFDF3; color: #027A48; }
        .pill-pending  { background: #FFFAEB; color: #B54708; }
        .pill-failed   { background: #FEF3F2; color: #B42318; }
        .pill-inactive { background: #F2F4F7; color: #475467; }

        /* ---------- Section headers ---------- */
        .section-header {
            font-size: 1.05rem;
            font-weight: 700;
            color: #1A1F36;
            margin-top: 1.6rem;
            margin-bottom: 0.6rem;
            border-left: 4px solid #2E6FF2;
            padding-left: 0.6rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


# ---------------------------------------------------------------------------
# SIDEBAR — same filter panel rendered on every page
# ---------------------------------------------------------------------------
def render_sidebar() -> dict:
    """
    Renders the shared sidebar (logo, global filters, connection status).
    Returns a dict of the selected filter values so each page can use them.
    """
    with st.sidebar:
        st.markdown("### 🧊 AtScale Ops Console")
        st.caption("Internal utility · Snowflake + AtScale")
        st.divider()

        st.markdown("**Filters**")
        org = st.selectbox("Organization", ["default", "sales-org", "finance-org"], key="f_org")
        project = st.selectbox(
            "Project",
            ["All Projects", "Sales Insights", "Internet Sales", "WW Importers", "TPC-DS"],
            key="f_project",
        )
        cube = st.selectbox(
            "Cube / Model",
            ["All Cubes", "Internet Sales Cube", "Returns Cube", "Inventory Cube"],
            key="f_cube",
        )
        time_range = st.select_slider(
            "Time range",
            options=["Last 1h", "Last 24h", "Last 7d", "Last 30d"],
            value="Last 24h",
            key="f_time_range",
        )

        st.divider()
        st.markdown("**Environment**")
        env = st.radio("Target", ["Production", "Staging", "Dev"], horizontal=False, key="f_env")

        st.divider()
        st.markdown("**System status** *(mock)*")
        st.markdown(
            '<span class="pill pill-active">AtScale: Connected</span>',
            unsafe_allow_html=True,
        )
        st.write("")
        st.markdown(
            '<span class="pill pill-active">Snowflake: Connected</span>',
            unsafe_allow_html=True,
        )

        st.divider()
        st.caption("Last refreshed: mock data · not live")
        st.button("🔄 Refresh data", use_container_width=True)

    return {
        "org": org,
        "project": project,
        "cube": cube,
        "time_range": time_range,
        "env": env,
    }


# ---------------------------------------------------------------------------
# REUSABLE COMPONENTS
# ---------------------------------------------------------------------------
def kpi_card(label: str, value: str, delta: str | None = None, delta_dir: str = "flat") -> str:
    """Returns HTML for a single KPI card (use with st.markdown(..., unsafe_allow_html=True))."""
    delta_html = ""
    if delta:
        css_class = {"up": "kpi-delta-up", "down": "kpi-delta-down", "flat": "kpi-delta-flat"}[delta_dir]
        arrow = {"up": "▲", "down": "▼", "flat": "•"}[delta_dir]
        delta_html = f'<div class="{css_class}">{arrow} {delta}</div>'

    return f"""
    <div class="kpi-card">
        <div class="kpi-label">{label}</div>
        <div class="kpi-value">{value}</div>
        {delta_html}
    </div>
    """


def feature_box(icon: str, title: str, desc: str, page_path: str) -> None:
    """Renders a clickable feature box that links to another page in the app."""
    st.markdown(
        f"""
        <div class="feature-box">
            <div class="feature-icon">{icon}</div>
            <div class="feature-title">{title}</div>
            <div class="feature-desc">{desc}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.page_link(page_path, label="Open →", use_container_width=True)
