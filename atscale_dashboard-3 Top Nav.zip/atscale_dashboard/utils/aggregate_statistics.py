"""
Aggregate statistics — adapted from aggregate_statistics.py.
Instead of printing to console (as the original CLI tool does), this
returns one summary ROW per cube so multiple cubes can be combined into
a single sortable/filterable table when "All Cubes" is selected.
"""

from __future__ import annotations

import pandas as pd


def compute_cube_statistics(cube_name: str, df: pd.DataFrame) -> dict:
    """One summary row for a single cube's aggregate set."""
    if df.empty:
        return {
            "cube": cube_name,
            "total_aggregates": 0,
            "active": 0,
            "failed": 0,
            "total_rows": 0,
            "avg_build_duration_sec": 0.0,
            "max_build_duration_sec": 0,
            "total_size_mb": 0.0,
        }

    status = df["status"].str.lower() if "status" in df else pd.Series(dtype=str)
    return {
        "cube": cube_name,
        "total_aggregates": len(df),
        "active": int((status == "active").sum()),
        "failed": int((status == "failed").sum()),
        "total_rows": int(df["rows_materialized"].sum()),
        "avg_build_duration_sec": round(float(df["build_duration_sec"].mean()), 1),
        "max_build_duration_sec": int(df["build_duration_sec"].max()),
        "total_size_mb": round(float(df["size_bytes"].sum()) / (1024 * 1024), 2),
    }


def compute_statistics_table(cube_dataframes: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """cube_dataframes: {cube_name: aggregates_df} -> one combined stats table."""
    rows = [compute_cube_statistics(name, df) for name, df in cube_dataframes.items()]
    return pd.DataFrame(rows)
