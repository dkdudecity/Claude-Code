"""
Mock data generators.
Swap these out for real AtScale / Snowflake API calls later —
every page only imports from here, so that's the single place to change.
"""

import numpy as np
import pandas as pd


def get_kpi_summary() -> dict:
    """Landing page top-strip + second-strip KPI numbers (mocked)."""
    return {
        "total_aggregates": 482,
        "active_aggregates": 401,
        "pending_aggregates": 12,
        "failed_aggregates": 7,
        "total_queries_24h": 3841,
        "failed_queries_24h": 26,
        "avg_query_duration_ms": 842,
        "max_subquery_wait_ms": 2310,
    }


def get_query_volume_timeseries() -> pd.DataFrame:
    """7 days of hourly mock query volume for the trend chart."""
    rng = pd.date_range(end=pd.Timestamp.now(), periods=24 * 7, freq="h")
    rng_seed = np.random.default_rng(42)
    base = 120 + 40 * np.sin(np.linspace(0, 14 * np.pi, len(rng)))
    noise = rng_seed.normal(0, 12, len(rng))
    values = np.clip(base + noise, 5, None).round().astype(int)
    return pd.DataFrame({"timestamp": rng, "query_count": values})


def get_aggregates_table() -> pd.DataFrame:
    """Mock aggregate instance rows, matching AtScale's aggregate-instances API shape."""
    rng = np.random.default_rng(7)
    cubes = ["Internet Sales Cube", "Returns Cube", "Inventory Cube", "Finance Cube"]
    statuses = ["active", "pending", "inprogress", "failed", "cancelled", "unreliable"]
    weights = [0.60, 0.10, 0.08, 0.10, 0.07, 0.05]

    n = 25
    df = pd.DataFrame(
        {
            "aggregate_id": [f"agg-{i:04d}" for i in range(n)],
            "cube": rng.choice(cubes, n),
            "status": rng.choice(statuses, n, p=weights),
            "rows_materialized": rng.integers(1_000, 5_000_000, n),
            "build_duration_sec": rng.integers(5, 900, n),
            "last_build": pd.Timestamp.now() - pd.to_timedelta(rng.integers(1, 72, n), unit="h"),
        }
    )
    return df.sort_values("last_build", ascending=False).reset_index(drop=True)


def get_recent_queries_table() -> pd.DataFrame:
    """Mock recent query log, matching the query-monitoring API shape."""
    rng = np.random.default_rng(11)
    cubes = ["Internet Sales Cube", "Returns Cube", "Inventory Cube", "Finance Cube"]
    users = ["j.smith", "a.patel", "svc_bi_tool", "m.chen", "svc_etl"]
    statuses = ["Successful", "Successful", "Successful", "Failed", "Cancelled"]

    n = 20
    df = pd.DataFrame(
        {
            "query_id": [f"q-{rng.integers(10**7, 10**8-1)}" for _ in range(n)],
            "cube": rng.choice(cubes, n),
            "user": rng.choice(users, n),
            "status": rng.choice(statuses, n),
            "duration_ms": rng.integers(80, 6000, n),
            "started": pd.Timestamp.now() - pd.to_timedelta(rng.integers(1, 1440, n), unit="m"),
        }
    )
    return df.sort_values("started", ascending=False).reset_index(drop=True)


def get_pending_aggregate_batches() -> pd.DataFrame:
    """Mock list of aggregate batches available to trigger."""
    cubes = ["Internet Sales Cube", "Returns Cube", "Inventory Cube", "Finance Cube"]
    return pd.DataFrame(
        {
            "cube": cubes,
            "last_build_status": ["active", "failed", "active", "pending"],
            "aggregates_in_batch": [14, 6, 9, 3],
        }
    )
