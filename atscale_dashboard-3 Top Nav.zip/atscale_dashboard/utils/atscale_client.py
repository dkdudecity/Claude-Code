"""
Real AtScale client — adapted from rwidjaja/atscale-aggregate-util
(config.py + api_client.py), reshaped for use inside Streamlit.

IMPORTANT: This is a reconstruction of that repo's approach (JWT via
basic-auth handshake against the Design Center, REST calls for published
projects and aggregate instances) rather than a byte-for-byte copy.
Before pointing this at a real instance, verify the exact endpoint paths
and JSON field names against your AtScale instance's Swagger docs
(usually at https://<host>:10500/api-docs) and adjust the few spots
flagged "VERIFY" below — API paths can vary slightly by AtScale version.
"""

from __future__ import annotations

import requests
import pandas as pd


# ---------------------------------------------------------------------------
# Environment -> host/org mapping (fixed per your setup)
# ---------------------------------------------------------------------------
ENV_CONFIG = {
    "Dev":  {"host": "atscale.dev.com",  "org": "1234567890"},
    "Uat":  {"host": "atscale.uat.com",  "org": "0987654421"},
    "Prod": {"host": "atscale.prod.com", "org": "abcd1234"},
}

DESIGN_CENTER_PORT = 10500
ENGINE_PORT = 10502  # VERIFY: adjust if your instance uses a different engine port
INSTANCE_TYPE = "installer"  # fixed per your requirement


class AtScaleAuthError(Exception):
    """Raised when login against AtScale fails for any reason."""


def get_jwt_token(host: str, org: str, username: str, password: str,
                   verify_ssl: bool = True) -> str:
    """
    Authenticates against AtScale's Design Center auth endpoint and returns
    a bearer JWT string. Mirrors the repo's basic-auth handshake.
    """
    url = f"https://{host}:{DESIGN_CENTER_PORT}/{org}/auth"  # VERIFY exact path
    try:
        resp = requests.get(
            url,
            auth=(username, password),
            params={"instanceType": INSTANCE_TYPE},
            timeout=15,
            verify=verify_ssl,
        )
    except requests.exceptions.RequestException as exc:
        raise AtScaleAuthError(f"Could not reach {host}: {exc}") from exc

    if resp.status_code != 200:
        raise AtScaleAuthError(
            f"Authentication failed ({resp.status_code}): {resp.text[:200]}"
        )

    token = resp.text.strip().strip('"')
    if not token:
        raise AtScaleAuthError("Auth call succeeded but returned no token.")
    return token


class AtScaleAPIClient:
    """Thin wrapper around AtScale's REST APIs, scoped to one env/org/session."""

    def __init__(self, host: str, org: str, token: str, verify_ssl: bool = True):
        self.host = host
        self.org = org
        self.token = token
        self.verify_ssl = verify_ssl
        self.headers = {"Authorization": f"Bearer {token}"}

    # -- Published projects / cubes -----------------------------------------
    def get_published_projects(self) -> list[dict]:
        """
        Returns published catalogs/cubes as:
        [{"catalog_id":.., "catalog_name":.., "cubes":[{"model_id":.., "cube_name":..}, ...]}]
        """
        url = f"https://{self.host}:{DESIGN_CENTER_PORT}/{self.org}/projects/published"  # VERIFY
        resp = requests.get(url, headers=self.headers, timeout=20, verify=self.verify_ssl)
        resp.raise_for_status()
        data = resp.json()

        raw_catalogs = data.get("response", data) if isinstance(data, dict) else data
        projects = []
        for catalog in raw_catalogs:
            projects.append({
                "catalog_id": catalog.get("id") or catalog.get("catalogId"),
                "catalog_name": catalog.get("name") or catalog.get("caption"),
                "cubes": [
                    {"model_id": c.get("id"), "cube_name": c.get("name") or c.get("caption")}
                    for c in catalog.get("cubes", [])
                ],
            })
        return projects

    # -- Aggregate instances --------------------------------------------------
    def get_aggregates_by_cube(self, catalog_id: str, model_id: str, limit: int = 500) -> pd.DataFrame:
        """
        Returns aggregate instances for one cube. Columns: aggregate_id, status,
        rows_materialized, build_duration_sec, size_bytes, last_build.
        """
        url = f"https://{self.host}:{ENGINE_PORT}/aggregates/orgId/{self.org}/catalogId/{catalog_id}"  # VERIFY
        params = {"modelId": model_id, "limit": limit}
        resp = requests.get(url, headers=self.headers, params=params, timeout=30, verify=self.verify_ssl)
        resp.raise_for_status()
        payload = resp.json()

        rows = payload.get("response", {}).get("data", payload) if isinstance(payload, dict) else payload
        records = []
        for agg in rows:
            stats = agg.get("stats", {})
            records.append({
                "aggregate_id": agg.get("id"),
                "status": agg.get("status"),
                "rows_materialized": stats.get("numberOfRows", 0),
                "build_duration_sec": stats.get("buildDuration", 0),
                "size_bytes": stats.get("sizeInBytes", 0),
                "last_build": stats.get("materializationEndTime"),
            })
        df = pd.DataFrame.from_records(records)
        if not df.empty:
            df["last_build"] = pd.to_datetime(df["last_build"], errors="coerce")
        return df
