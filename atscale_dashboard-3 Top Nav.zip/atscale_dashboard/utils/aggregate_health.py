"""
Aggregate health checks — adapted from aggregate_health_checker.py.
Returns one summary row per cube (score + issue/warning counts) for the
combined table, plus a helper to list the underlying issue rows for
drill-down when a single cube is selected.
"""

from __future__ import annotations

import pandas as pd

STALE_DAYS_THRESHOLD = 7


def _issues_for_cube(cube_name: str, df: pd.DataFrame) -> pd.DataFrame:
    """Row-level issues: failed builds, stale builds, zero-row aggregates."""
    if df.empty:
        return pd.DataFrame()

    issues = []
    now = pd.Timestamp.now()
    for _, row in df.iterrows():
        problems = []
        if str(row.get("status", "")).lower() == "failed":
            problems.append("build failed")
        if str(row.get("status", "")).lower() in ("cancelled", "invalid", "unreliable"):
            problems.append(f"status = {row.get('status')}")
        if pd.notna(row.get("last_build")) and (now - row["last_build"]).days > STALE_DAYS_THRESHOLD:
            problems.append(f"stale (> {STALE_DAYS_THRESHOLD}d since last build)")
        if row.get("rows_materialized", 0) == 0:
            problems.append("zero rows materialized")

        if problems:
            issues.append({
                "cube": cube_name,
                "aggregate_id": row.get("aggregate_id"),
                "status": row.get("status"),
                "last_build": row.get("last_build"),
                "issue": "; ".join(problems),
            })
    return pd.DataFrame(issues)


def compute_cube_health(cube_name: str, df: pd.DataFrame) -> dict:
    """One summary row: health score (0-100) + issue/warning counts for a cube."""
    if df.empty:
        return {"cube": cube_name, "health_score": 0, "issues": 0, "warnings": 0, "total_aggregates": 0}

    issues_df = _issues_for_cube(cube_name, df)
    total = len(df)
    hard_issues = int((issues_df["issue"].str.contains("failed|stale", case=False)).sum()) if not issues_df.empty else 0
    warnings = len(issues_df) - hard_issues if not issues_df.empty else 0

    score = max(0, round(100 - (hard_issues / total * 100) - (warnings / total * 30))) if total else 0
    return {
        "cube": cube_name,
        "health_score": score,
        "issues": hard_issues,
        "warnings": max(warnings, 0),
        "total_aggregates": total,
    }


def compute_health_table(cube_dataframes: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """cube_dataframes: {cube_name: aggregates_df} -> one combined health-summary table."""
    rows = [compute_cube_health(name, df) for name, df in cube_dataframes.items()]
    return pd.DataFrame(rows)


def compute_all_issues(cube_dataframes: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Combined row-level issue detail across every cube, for drill-down."""
    frames = [_issues_for_cube(name, df) for name, df in cube_dataframes.items()]
    frames = [f for f in frames if not f.empty]
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)
